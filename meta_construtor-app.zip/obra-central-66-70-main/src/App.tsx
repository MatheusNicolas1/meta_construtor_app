import { PerformanceOptimizedApp } from "@/components/PerformanceOptimizedApp";
import { performanceMonitor } from "@/utils/performanceMonitor";
import "./utils/clearDebugData"; // Limpar dados de debug

// Inicializar monitor de performance
if (typeof window !== 'undefined') {
  setTimeout(() => {
    performanceMonitor.start();
  }, 500);
}

const App = () => <PerformanceOptimizedApp />;

export default App;