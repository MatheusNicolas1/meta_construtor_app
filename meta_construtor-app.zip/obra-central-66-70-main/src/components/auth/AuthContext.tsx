import React, { createContext, useCallback, useContext, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { User, UserRole } from "@/types/user";

interface AuthContextValue {
  isAuthenticated: boolean;
  user: User | null;
  roles: UserRole[];
  attributes: Record<string, any>;
  mfaEnabled: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => void;
  hasRole: (role: UserRole) => boolean;
  hasAnyRole: (roles: UserRole[]) => boolean;
  refreshSession: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const navigate = useNavigate();
  
  // Estado simplificado - sempre autenticado como Administrador
  const [user] = useState<User>({
    id: "admin_user",
    name: "Administrador",
    email: "admin@meta-construtor.com",
    role: "Administrador",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  });

  const isAuthenticated = true;
  const roles = ["Administrador"] as UserRole[];
  const attributes = {};
  const mfaEnabled = false;

  const signIn = useCallback(async (email: string, _password: string) => {
    // Simplesmente redireciona para o dashboard sem verificações
    console.log("✅ Login realizado, redirecionando para dashboard...");
    window.location.replace("/dashboard");
  }, []);

  const signOut = useCallback(() => {
    // Não fazer nada - manter sempre logado em desenvolvimento
    console.log("Logout desabilitado em desenvolvimento");
  }, []);

  const hasRole = useCallback(() => true, []);
  const hasAnyRole = useCallback(() => true, []);
  const refreshSession = useCallback(async () => {
    // Não fazer nada
  }, []);

  const value = useMemo<AuthContextValue>(() => ({
    isAuthenticated,
    user,
    roles,
    attributes,
    mfaEnabled,
    signIn,
    signOut,
    hasRole,
    hasAnyRole,
    refreshSession,
  }), [isAuthenticated, user, roles, attributes, mfaEnabled, signIn, signOut, hasRole, hasAnyRole, refreshSession]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    // Retornar valores padrão seguros sempre permitindo acesso
    return {
      isAuthenticated: true,
      user: {
        id: "default_admin",
        name: "Administrador",
        email: "admin@meta-construtor.com",
        role: "Administrador" as UserRole,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      roles: ["Administrador"] as UserRole[],
      attributes: {},
      mfaEnabled: false,
      signIn: async () => { window.location.replace("/dashboard"); },
      signOut: () => {},
      hasRole: () => true,
      hasAnyRole: () => true,
      refreshSession: async () => {},
    } as AuthContextValue;
  }
  return ctx;
};