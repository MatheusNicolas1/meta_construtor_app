import React from "react";
import type { UserRole } from "@/types/user";

interface ProtectedRouteProps {
  children: React.ReactNode;
  roles?: UserRole[];
  requiredPermissions?: string[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  // Em desenvolvimento, SEMPRE permitir acesso a tudo sem verificações
  console.log('✅ ProtectedRoute - Acesso livre em desenvolvimento');
  return <>{children}</>;
};

export default ProtectedRoute;