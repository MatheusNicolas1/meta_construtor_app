import { BackgroundPaths } from "@/components/ui/background-paths"

export function DemoBackgroundPaths() {
    return <BackgroundPaths title="Background Paths" />
}