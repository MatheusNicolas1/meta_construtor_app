// Importar componente otimizado
import OptimizedDashboard from "@/components/OptimizedDashboard";

const Dashboard = () => {
  return <OptimizedDashboard />;
};

export default Dashboard;