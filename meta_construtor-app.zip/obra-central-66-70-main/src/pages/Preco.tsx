import React from 'react';
import { useNavigate } from 'react-router-dom';
import SEO from "@/components/SEO";
import LandingNavigation from '@/components/landing/LandingNavigation';
import { Pricing } from '@/components/ui/pricing';
import FooterSection from '@/components/landing/FooterSection';
import { PerformanceManager } from '@/components/PerformanceManager';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const demoPlans = [
  {
    name: "FREE",
    price: "0",
    yearlyPrice: "0",
    period: "por 14 dias",
    features: [
      "Teste gratuito de 14 dias",
      "1 usuário",
      "1 obra",
      "RDO básico",
      "Suporte por email",
      "Sem cartão de crédito",
    ],
    description: "Experimente todas as funcionalidades sem compromisso",
    buttonText: "Começar Grátis",
    href: "/checkout?plan=free",
    isPopular: false,
  },
  {
    name: "BÁSICO",
    price: "129,90",
    yearlyPrice: "103,92",
    period: "por mês",
    features: [
      "Até 3 usuários",
      "Armazenamento ilimitado",
      "RDO digital completo",
      "Relatórios básicos",
      "Suporte por email",
      "Backup automático",
    ],
    description: "Perfeito para pequenas construtoras",
    buttonText: "Começar Agora",
    href: "/checkout?plan=basic",
    isPopular: false,
  },
  {
    name: "PROFISSIONAL",
    price: "199,90",
    yearlyPrice: "159,92",
    period: "por mês",
    features: [
      "Até 5 usuários",
      "Obras ilimitadas",
      "Relatórios avançados",
      "Integrações WhatsApp",
      "Suporte via chat 24h",
      "Dashboard avançado",
      "Controle de estoque",
    ],
    description: "Ideal para construtoras em crescimento",
    buttonText: "Começar Agora",
    href: "/checkout?plan=professional",
    isPopular: true,
  },
  {
    name: "MASTER",
    price: "499,90",
    yearlyPrice: "399,92",
    period: "por mês",
    features: [
      "Até 15 usuários",
      "Obras ilimitadas",
      "Todas as funcionalidades do Profissional",
      "API personalizada",
      "Integração com ERP",
      "Suporte prioritário (SLA 8h)",
      "Treinamento dedicado",
    ],
    description: "Para construtoras estabelecidas",
    buttonText: "Começar Agora",
    href: "/checkout?plan=master",
    isPopular: false,
  },
  {
    name: "BUSINESS",
    price: "Sob consulta",
    yearlyPrice: "Sob consulta",
    period: "",
    features: [
      "Usuários ilimitados",
      "Integrações customizadas",
      "SLA 24/7",
      "Onboarding dedicado",
      "Gerente de conta exclusivo",
      "White label disponível",
      "Múltiplas empresas",
    ],
    description: "Para grandes incorporadoras e construtoras",
    buttonText: "Solicitar Proposta",
    href: "/checkout?plan=business",
    isPopular: false,
  },
];

const Preco = () => {
  const navigate = useNavigate();
  
  return (
    <PerformanceManager>
      <SEO 
        title="Preços - Meta Construtor | Planos e Valores"
        description="Conheça nossos planos de preços. Desde R$ 129,90/mês. Teste gratuito de 14 dias. Escolha o plano ideal para sua construtora."
        canonical={window.location.href}
      />
      
      <div className="min-h-screen bg-background">
        <LandingNavigation />
        
        <main className="pt-16">
          <section id="pricing" className="py-12 md:py-16 lg:py-20">
            {/* Badge Gestão Inteligente de Obras */}
            <div className="text-center mb-4 max-w-[960px] w-[90%] mx-auto px-2 sm:px-4">
              <Link
                to="/login"
                className="hover:bg-background dark:hover:border-t-border bg-muted group mx-auto flex w-fit items-center gap-2 sm:gap-3 md:gap-4 rounded-full border p-1 pl-2 sm:pl-3 md:pl-4 shadow-md shadow-black/5 transition-all duration-300 dark:border-t-white/5 dark:shadow-zinc-950 text-xs sm:text-sm touch-manipulation">
                <span className="text-foreground px-1">Gestão Inteligente de Obras</span>
                <span className="dark:border-background block h-3 sm:h-4 w-0.5 border-l bg-white dark:bg-zinc-700"></span>
                <div className="bg-background group-hover:bg-muted size-4 sm:size-5 md:size-6 overflow-hidden rounded-full duration-500">
                  <div className="flex w-8 sm:w-10 md:w-12 -translate-x-1/2 duration-500 ease-in-out group-hover:translate-x-0">
                    <span className="flex size-4 sm:size-5 md:size-6">
                      <ArrowRight className="m-auto size-2 sm:size-2.5 md:size-3" />
                    </span>
                    <span className="flex size-4 sm:size-5 md:size-6">
                      <ArrowRight className="m-auto size-2 sm:size-2.5 md:size-3" />
                    </span>
                  </div>
                </div>
              </Link>
            </div>
            
            <Pricing 
              plans={demoPlans}
              title="Planos que se adaptam ao seu negócio"
              description="Escolha o plano ideal para sua construtora. Todos os planos incluem acesso completo à plataforma, suporte técnico e atualizações gratuitas."
            />
          </section>
        </main>
        
        <FooterSection />
      </div>
    </PerformanceManager>
  );
};

export default Preco;